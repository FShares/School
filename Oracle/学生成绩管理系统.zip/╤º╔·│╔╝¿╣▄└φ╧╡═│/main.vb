﻿Public Class main
    Private Sub main_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not userlevel = "系统管理员" Then '限制非管理员权限
            学生数据编辑ToolStripMenuItem.Enabled = False
            教师数据编辑ToolStripMenuItem.Enabled = False
            课程数据编辑ToolStripMenuItem.Enabled = False
            安排任课教师ToolStripMenuItem.Enabled = False
            成绩数据编辑ToolStripMenuItem.Enabled = False
            设置系统用户ToolStripMenuItem.Enabled = False
            班级数据编辑ToolStripMenuItem.Enabled = False
            系统初始化ToolStripMenuItem.Enabled = False
        End If
        ToolStripStatusLabel1.text() = "当前用户为：" + no + "    登录时间为：" + logontime.ToLongDateString + logontime.ToLongTimeString
    End Sub

    Private Sub 学生数据编辑ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 学生数据编辑ToolStripMenuItem.Click
        editstudent.ShowDialog()
    End Sub

    Private Sub 学生数据查询ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 学生数据查询ToolStripMenuItem.Click
        querystudent.showdialog()
    End Sub

    Private Sub 退出CtrlXToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 退出CtrlXToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub 教师数据编辑ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 教师数据编辑ToolStripMenuItem.Click
        editteacher.ShowDialog()
    End Sub

    Private Sub 教师数据查询ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 教师数据查询ToolStripMenuItem.Click
        queryteacher.showdialog()
    End Sub

    Private Sub 课程数据编辑ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 课程数据编辑ToolStripMenuItem.Click
        editcourse.ShowDialog()
    End Sub

    Private Sub 课程数据查询ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 课程数据查询ToolStripMenuItem.Click
        querycourse.showdialog()
    End Sub

    Private Sub 安排任课教师ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 安排任课教师ToolStripMenuItem.Click
        allocateCourse.ShowDialog()
    End Sub

    Private Sub 查询任课教师ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 查询任课教师ToolStripMenuItem.Click
        queryallocate.showdialog()
    End Sub

    Private Sub 成绩数据编辑ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 成绩数据编辑ToolStripMenuItem.Click
        editscore.ShowDialog()
    End Sub

    Private Sub 成绩数据查询ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 成绩数据查询ToolStripMenuItem.Click
        queryscore.ShowDialog()
    End Sub

    Private Sub 设置系统用户ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 设置系统用户ToolStripMenuItem.Click
        setuser.ShowDialog()
    End Sub

    Private Sub 系统初始化ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 系统初始化ToolStripMenuItem.Click
        If MsgBox("本功能要清除系统中所有数据，真的初始化吗？", MsgBoxStyle.YesNo, "确认初始化操作") = vbYes Then
            Exesql("delete score")
            Exesql("delete allocate")
            Exesql("delete student")
            Exesql("delete teacher")
            Exesql("delete course")
            Exesql("delete users")
            Exesql("delete class")
            Exesql("INSERT into users values('admin','123456','系统管理员')")
            MsgBox("系统初始化完毕。" & Chr(13) & Chr(10) & "注意：下次只能以admin/123456(用户名/口令)进入本系统", MsgBoxStyle.OkOnly, "信息提示")
        End If
    End Sub

    Private Sub MenuStrip1_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub

    Private Sub 班级数据编辑ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 班级数据编辑ToolStripMenuItem.Click
        editClass.ShowDialog()
    End Sub

    Private Sub 班级数据查询ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 班级数据查询ToolStripMenuItem.Click
        queryClass.ShowDialog()
    End Sub
End Class