Public Class allocateCourse1

    Private Sub allocateCourse1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        mytable = Exesql("select distinct ��� from student where ��� is not null")
        ComboBox1.DataSource = mytable
        ComboBox1.DisplayMember = "���"
        ComboBox1.SelectedIndex = -1

        mytable = exesql("select distinct �γ̺� from course")
        ComboBox2.DataSource = mytable
        ComboBox2.DisplayMember = "�γ̺�"
        ComboBox2.SelectedIndex = -1

        mytable = exesql("Select distinct ��� from teacher")
        ComboBox3.DataSource = mytable
        ComboBox3.DisplayMember = "���"
        ComboBox3.SelectedIndex = -1
        If flag = 1 Then
            ComboBox1.SelectedIndex = -1
            ComboBox2.SelectedIndex = -1
            ComboBox3.SelectedIndex = -1
            ComboBox1.Enabled = True
            ComboBox2.Enabled = True
        Else
            mytable = Exesql("select * from allocate where ��� = '" + no.Trim + "' and �γ̺�='" + cno.Trim + "'")
            ComboBox1.Text = mytable.Rows(0)("���").ToString
            ComboBox2.Text = mytable.Rows(0)("�γ̺�").ToString
            ComboBox3.Text = mytable.Rows(0)("��ʦ���").ToString
            ComboBox1.Enabled = False
            ComboBox2.Enabled = False
        End If
    End Sub

    Private Sub OkButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OkButton.Click
        If ComboBox1.Text.Trim = "" Then
            MsgBox("����������", MsgBoxStyle.OkOnly, "��Ϣ��ʾ")
            Exit Sub
        End If
        If ComboBox2.Text.Trim = "" Then
            MsgBox("��������γ̺�", MsgBoxStyle.OkOnly, "��Ϣ��ʾ")
            Exit Sub
        End If
        If flag = 1 Then
            mysql = "select * from allocate where ���='" + ComboBox1.Text.Trim + "' and �γ̺�='" + ComboBox2.Text.Trim & "'"
            mytable = Exesql(mysql)
            If mytable.Rows.Count = 1 Then
                MsgBox("����İ�źͿγ̺��ظ������ܰ����ον�ʦ", MsgBoxStyle.OkOnly, "��Ϣ��ʾ")
                Exit Sub
            Else
                mysql = "insert into allocate values('" + ComboBox1.Text.Trim + "','" + ComboBox2.Text.Trim + "','" + ComboBox3.Text.Trim + "')"
                Exesql(mysql)
                Me.Close()
            End If
        Else
            mysql = "update allocate set ��ʦ���='" & ComboBox3.Text.Trim + "' where ���='" + ComboBox1.Text.Trim + "' and �γ̺�='" + ComboBox2.Text + "'"
            exesql(mysql)
            Me.Close()
        End If
    End Sub

    Private Sub CancelButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelButton.Click
        Me.Close()
    End Sub
End Class