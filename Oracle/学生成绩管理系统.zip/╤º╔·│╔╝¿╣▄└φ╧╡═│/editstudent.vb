﻿Public Class editstudent

    Private Sub editstudent_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        mytable = Exesql("select * from student")

        DataGridView1.AllowUserToAddRows = False
        DataGridView1.ReadOnly = True
        DataGridView1.DataSource = mytable
        DataGridView1.GridColor = Color.Green
        DataGridView1.ScrollBars = ScrollBars.Both
        Call enbutton()
    End Sub

    Private Sub AddButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddButton.Click
        flag = 1
        editstudent1.ShowDialog()
        mytable = Exesql("select * from student")
        DataGridView1.DataSource = mytable
        Call enbutton()
    End Sub

    Private Sub UpdateButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UpdateButton.Click
        flag = 2
        If no <> "" Then
            editstudent1.ShowDialog()
            mytable = Exesql("select * from student")
            DataGridView1.DataSource = mytable
            Call enbutton()
        Else
            MsgBox("先选择要修改的学生记录", MsgBoxStyle.OkOnly, "信息提示")
        End If
    End Sub

    Private Sub DeleteButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteButton.Click
        If no <> "" Then
            If MsgBox("真的要删除学号为" & no.Trim & "的学生记录吗？", MsgBoxStyle.YesNo, "删除确认") = MsgBoxResult.Yes Then
                mysql = "delete student where 学号='" & no & "'"
                Exesql(mysql)
                mytable = Exesql("select * from student")
                DataGridView1.DataSource = mytable
                Call enbutton()
            End If
        Else
            MsgBox("先选择要删除的学生记录", MsgBoxStyle.OkOnly, "信息提示")
        End If
    End Sub

    Private Sub ReturnButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReturnButton.Click
        Me.Close()
    End Sub

    Private Sub enbutton()
        Label1.Text = "满足条件的学生记录个数：" + mytable.Rows.Count.ToString
        If mytable.Rows.Count = 0 Then
            UpdateButton.Enabled = False
            DeleteButton.Enabled = False
            no = ""
        Else
            UpdateButton.Enabled = True
            DeleteButton.Enabled = True
            no = mytable.Rows.Item(0)("学号")
        End If
    End Sub

    Private Sub DataGridView1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        If e.RowIndex >= 0 And e.RowIndex < DataGridView1.RowCount Then
            no = DataGridView1.Rows(e.RowIndex).Cells(0).Value
        Else
            no = ""
        End If
    End Sub
End Class