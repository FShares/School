Public Class queryallocate

    Private Sub queryallocate_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        mysql = "select ���,allocate.�γ̺�,�γ���,allocate.��ʦ���,���� " + "from allocate,course,teacher " + "where allocate.�γ̺�=course.�γ̺� and allocate.��ʦ��� = teacher.���"
        mytable = exesql(mysql)
        mydv = mytable.DefaultView

        DataGridView1.AllowUserToAddRows = False
        DataGridView1.ReadOnly = True
        DataGridView1.DataSource = mydv
        DataGridView1.GridColor = Color.Green
        DataGridView1.ScrollBars = ScrollBars.Both

        Label1.Text = "���������İ����ον�ʦ��¼������" + mydv.Count.ToString()

        mytable = exesql("select distinct ��� from student where ��� is not null")
        ComboBox1.DataSource = mytable
        ComboBox1.DisplayMember = "���"

        mytable = exesql("Select distinct �γ̺� from course")
        ComboBox2.DataSource = mytable
        ComboBox2.DisplayMember = "�γ̺�"

        mytable = exesql("select distinct ��� from teacher")
        ComboBox3.DataSource = mytable
        ComboBox3.DisplayMember = "���"

        ComboBox1.SelectedIndex = -1
        ComboBox2.SelectedIndex = -1
        ComboBox3.SelectedIndex = -1
    End Sub

    Private Sub OkButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OkButton.Click
        condstr = ""
        If ComboBox1.Text <> "" Then
            condstr = "��� like '%" & ComboBox1.Text.Trim & "%'"
        End If
        If ComboBox2.Text <> "" Then
            If condstr <> "" Then
                condstr = condstr & " and �γ̺� like '%" & ComboBox2.Text.Trim & "%'"
            Else
                condstr = "�γ̺� like '%" & ComboBox2.Text.Trim & "%'"
            End If
        End If
        If ComboBox3.Text <> "" Then
            If condstr <> "" Then
                condstr = condstr & " and ��ʦ��� like '%" & ComboBox3.Text.Trim & "%'"
            Else
                condstr = "��ʦ��� like '%" & ComboBox3.Text.Trim & "%'"
            End If
        End If
        mydv.RowFilter = condstr
        Label1.Text = "���������İ����ον�ʦ��¼����:" + mydv.Count.ToString()
    End Sub

    Private Sub ReSetButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReSetButton.Click
        ComboBox1.Text = ""
        ComboBox2.Text = ""
        ComboBox3.Text = ""
    End Sub

    Private Sub ReturnButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReturnButton.Click
        Me.Close()
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class