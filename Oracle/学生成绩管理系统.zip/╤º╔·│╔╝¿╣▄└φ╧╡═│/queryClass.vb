﻿Public Class queryClass

    Private Sub OkButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OkButton.Click
        condstr = ""
        If TextBox1.Text <> "" Then
            condstr = "班号 Like '%" & TextBox1.Text & "%'"
        End If
        If TextBox2.Text <> "" Then
            If condstr <> "" Then
                condstr = condstr & "AND 班级名 Like '%" & TextBox2.Text & "%'"
            Else
                condstr = "班级名 like '%" & TextBox2.Text & "%'"
            End If
        End If
        mydv.RowFilter = condstr
        Label1.Text = "满足条件的记录个数:" + mydv.Count.ToString
    End Sub

    Private Sub queryClass_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        mytable = Exesql("select * from class")
        mydv = mytable.DefaultView
        DataGridView1.AllowUserToAddRows = False
        DataGridView1.ReadOnly = True
        DataGridView1.DataSource = mydv
        DataGridView1.GridColor = Color.Green
        TextBox1.Text = ""
        TextBox2.Text = ""
        Label1.Text = "满足条件的记录个数: " + mydv.Count.ToString()
    End Sub

    Private Sub ReSetButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReSetButton.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
    End Sub

    Private Sub ReturnButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReturnButton.Click
        Me.Close()
    End Sub
End Class