﻿Public Class setuser1

    Private Sub CancelButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelButton.Click
        Me.Close()
    End Sub

    Private Sub OkButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OkButton.Click
        If Trim(TextBox1.Text) = "" Then
            MsgBox("必须输入用户名", MsgBoxStyle.OkOnly, "信息提示")
            Exit Sub
        End If
        If Trim(TextBox2.Text) = "" Then
            MsgBox("必须输入口令", MsgBoxStyle.OkOnly, "信息提示")
            Exit Sub
        End If
        If Trim(ComboBox1.Text) = "" Then
            MsgBox("必须选择级别", MsgBoxStyle.OkOnly, "信息提示")
            Exit Sub
        End If
        If flag = 1 Then
            mysql = "select * from users where 用户名='" & TextBox1.Text.Trim & "'"
            mytable = Exesql(mysql)
            If mytable.Rows.Count = 1 Then
                MsgBox("输入的用户名重复，不能新增", MsgBoxStyle.OkOnly, "信息提示")
                TextBox1.Focus()
                Exit Sub
            Else
                mysql = "insert into users values('" & TextBox1.Text & "','" & TextBox2.Text + "','" & ComboBox1.Text & "')"
                Exesql(mysql)
                Me.Close()
            End If
        Else
            mysql = "update users set 密码='" & TextBox2.Text & "',级别='" & ComboBox1.Text & "' where 用户名='" & TextBox1.Text & "'"
            Exesql(mysql)
            Me.Close()
        End If
    End Sub

    Private Sub setuser1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboBox1.Items.Clear()
        ComboBox1.Items.Add("系统管理员")
        ComboBox1.Items.Add("一般操作员")
        If flag = 1 Then
            TextBox1.Text = ""
            TextBox2.Text = ""
            ComboBox1.Text = ""
            TextBox1.Enabled = True
            TextBox1.Focus()
        Else
            mytable = Exesql("select * from users where 用户名='" & no & "'")
            TextBox1.Text = mytable.Rows(0)("用户名").ToString
            TextBox2.Text = mytable.Rows(0)("密码").ToString
            ComboBox1.Text = mytable.Rows(0)("级别").ToString
            TextBox1.Enabled = False
            TextBox2.Focus()
        End If
    End Sub
End Class