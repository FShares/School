﻿Public Class querystudent

    Private Sub OkButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OkButton.Click
        condstr = ""
        If TextBox1.Text <> "" Then
            condstr = "学号 like '%" & TextBox1.Text & "%'"
        End If
        if TextBox2.Text<>"" Then
            if condstr<>"" Then
                condstr = condstr & " and 姓名 like '%" & TextBox2.Text & "%'"
            else
                condstr="姓名 like '%" & TextBox2.text & "%'"
            end if
        end if

        if Radiosex1.Checked Then
            if condstr<> "" Then
                condstr=condstr+" and 性别='男'"
            else
                condstr="性别='男'"
            end if
        elseif Radiosex2.Checked Then
            if condstr<> "" Then
                condstr=condstr+" and 性别='女'"
            else
                condstr="性别='女'"
            end if
        end if

        if ComboBox1.text<>"" Then
            if condstr<>"" Then
                condstr=condstr & " and 班号='" & ComboBox1.text & "'"
            else
                condstr="班号 ='" & ComboBox1.text & "'"
            end if
        end if

        mydv.rowfilter=condstr
        Label1.text="满足条件的学生记录个数："+mydv.count.ToString()
            
    End Sub

    Private Sub querystudent_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        mytable = Exesql("select * from student")
        mydv = mytable.DefaultView

        DataGridView1.AllowUserToAddRows = False
        DataGridView1.ReadOnly = True
        DataGridView1.DataSource = mydv
        DataGridView1.GridColor = Color.Green
        DataGridView1.ScrollBars = ScrollBars.Both
        Label1.Text = "满足条件的学生记录个数：" + mydv.Count.ToString()

        mytable = Exesql("select distinct 班号 from student where 班号 is not null")
        ComboBox1.DataSource = mytable
        ComboBox1.DisplayMember = "班号"

        TextBox1.Text = ""
        TextBox2.Text = ""
        ComboBox1.Text = ""
        Radiosex1.Checked = False
        Radiosex2.Checked = False

    End Sub

    Private Sub ReSetButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReSetButton.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        ComboBox1.Text = ""
        Radiosex1.Checked = False
        Radiosex2.Checked = False

    End Sub

    Private Sub ReturnButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReturnButton.Click
        Me.Close()
    End Sub
End Class