﻿Public Class queryscore
    Private Sub queryscore_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mysql = "select score.学号,姓名,score.课程号,课程名,分数 " + "from score,student,course " + "where score.学号=student.学号 and score.课程号=course.课程号"
        mytable = Exesql(mysql)
        mydv = mytable.DefaultView

        DataGridView1.AllowUserToAddRows = False
        DataGridView1.ReadOnly = True
        DataGridView1.DataSource = mydv
        DataGridView1.GridColor = Color.Green
        DataGridView1.ScrollBars = ScrollBars.Both

        mytable = Exesql("select 学号 from student")
        ComboBox1.DataSource = mytable
        ComboBox1.DisplayMember = "学号"
        ComboBox1.SelectedIndex = -1

        mytable = Exesql("select 课程号 from course")
        ComboBox2.DataSource = mytable
        ComboBox2.DisplayMember = "课程号"
        ComboBox2.SelectedIndex = -1

        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        Label1.Text = "满足条件的成绩记录个数：" + mydv.Count.ToString()
    End Sub

    Private Sub OkButton_Click(sender As Object, e As EventArgs) Handles OkButton.Click
        If TextBox2.Text <> "" Then
            If TextBox3.Text = "" Then
                MsgBox("分数的上限未输入", MsgBoxStyle.OkOnly, "信息提示")
                Exit Sub
            ElseIf CInt(TextBox2.Text) > CInt(TextBox3.Text) Then
                MsgBox("输入的分数范围不正确", MsgBoxStyle.OkOnly, "信息提示")
                Exit Sub
            End If
        ElseIf TextBox3.Text <> "" Then
            MsgBox("分数的下限未输入", MsgBoxStyle.OkOnly, "信息提示")
            Exit Sub
        End If
        condstr = ""
        If ComboBox1.Text <> "" Then
            condstr = "学号 like '%" & ComboBox1.Text.Trim & "%'"
        End If

        If TextBox1.Text <> "" Then
            If condstr <> "" Then
                condstr = condstr + " and 姓名 like '%" & TextBox1.Text.Trim & "%'"
            Else
                condstr = "姓名 like '%" & TextBox1.Text.Trim & "%'"
            End If
        End If

        If ComboBox2.Text <> "" Then
            If condstr <> "" Then
                condstr += " and 课程号 like '%" & ComboBox2.Text.Trim & "%'"
            Else
                condstr = "课程号 like '%" & ComboBox2.Text.Trim & "%'"
            End If
        End If

        If TextBox2.Text <> "" Then
            If condstr <> "" Then
                condstr += " and 分数>=" + TextBox2.Text.Trim + "and 分数<=" + TextBox3.Text.Trim
            Else
                condstr = "分数>=" + TextBox2.Text.Trim + "and 分数<=" + TextBox3.Text.Trim
            End If
        End If

        mydv.RowFilter = condstr
        Label1.Text = "满足条件的成绩记录个数：" + mydv.Count.ToString()
    End Sub

    Private Sub ReSetButton_Click(sender As Object, e As EventArgs) Handles ReSetButton.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        ComboBox1.Text = ""
        ComboBox2.Text = ""
    End Sub

    Private Sub ReturnButton_Click(sender As Object, e As EventArgs) Handles ReturnButton.Click
        Me.Close()
    End Sub
End Class