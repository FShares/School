﻿Public Class setuser
    Private Sub setuser_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        mytable = Exesql("select * from users order by 级别,用户名")
        DataGridView1.AllowUserToAddRows = False
        DataGridView1.ReadOnly = True
        DataGridView1.DataSource = mytable
        DataGridView1.GridColor = Color.Green
        DataGridView1.ScrollBars = ScrollBars.Both
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        If e.RowIndex >= 0 And e.RowIndex < DataGridView1.RowCount Then
            no = DataGridView1.Rows(e.RowIndex).Cells(0).Value
        Else
            no = ""
        End If
    End Sub

    Private Sub AddButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddButton.Click
        flag = 1
        setuser1.ShowDialog()
        mytable = Exesql("select * from users order by 级别,用户名")
        DataGridView1.DataSource = mytable
    End Sub

    Private Sub UpdateButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UpdateButton.Click
        flag = 2
        If no <> "" Then
            setuser1.ShowDialog()
        End If
    End Sub

    Private Sub DeleteButton_Click(sender As Object, e As EventArgs) Handles DeleteButton.Click
        If no <> "" Then
            If no.Trim <> "admin" Then
                If MsgBox("真的要删除编号为" & no.Trim & "的用户吗？", MsgBoxStyle.YesNo, "删除确认") = MsgBoxResult.Yes Then
                    mysql = "delete users where 用户名='" & no & "'"
                    Exesql(mysql)
                    mytable = Exesql("select * from users order by 级别,用户名")
                    DataGridView1.DataSource = mytable
                End If
            Else
                MsgBox("admin用户不能删除！", MsgBoxStyle.OkOnly, "信息提示")
            End If
        Else
            MsgBox("先选择要删除的用户记录", MsgBoxStyle.OkOnly, "信息提示")
        End If
    End Sub

    Private Sub ReturnButton_Click(sender As Object, e As EventArgs) Handles ReturnButton.Click
        Me.Close()
    End Sub
End Class