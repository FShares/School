Public Class editcourse1

    Private Sub editcourse1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If flag = 1 Then
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox1.Enabled = True
            TextBox1.Focus()
        Else
            mytable = Exesql("Select * from course where �γ̺�='" & no & "'")
            TextBox1.Text = mytable.Rows(0)("�γ̺�").ToString.Trim
            TextBox2.Text = mytable.Rows(0)("�γ���").ToString.Trim
            TextBox1.Enabled = False
            TextBox2.Focus()
        End If
    End Sub

    Private Sub OkButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OkButton.Click
        If TextBox1.Text.Trim = "" Then
            MsgBox("��������γ̺�", MsgBoxStyle.OkOnly, "��Ϣ��ʾ")
            Exit Sub
        End If
        If TextBox2.Text.Trim = "" Then
            MsgBox("��������γ���", MsgBoxStyle.OkOnly, "��Ϣ��ʾ")
            Exit Sub
        End If
        If flag = 1 Then
            mytable = exesql("select * from course where �γ̺�='" & TextBox1.Text.Trim & "'")
            If mytable.Rows.Count = 1 Then
                MsgBox("����Ŀγ̺��ظ������������γ�", MsgBoxStyle.OkOnly, "��Ϣ��ʾ")
                TextBox1.Focus()
                Exit Sub
            Else
                mysql = "INSERT into course values('" & TextBox1.Text.Trim & "','" & TextBox2.Text.Trim & "')"
                exesql(mysql)
                Me.Close()
            End If
        Else
            mysql = "UPDATE course set �γ���='" & TextBox2.Text & "' Where  �γ̺�='" & TextBox1.Text & "'"
            exesql(mysql)
            Me.Close()
        End If
    End Sub

    Private Sub CancelButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelButton.Click
        Me.Close()
    End Sub
End Class
