﻿Imports System.Data.OracleClient
Public Class editscore
    Dim myconn As New OracleConnection
    Dim mystr As String
    Dim mysql As String
    Dim myda As New OracleDataAdapter
    Dim myds As New DataSet

    Private Sub editscore_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
 
        mystr = "data source=orcl;user id=scott;password=tiger"
        myconn.ConnectionString = mystr
        myconn.Open()
        mysql = "select * from score order by 课程号,学号"
        myda = New OracleDataAdapter(mysql, myconn)
        myds.Clear()
        myda.Fill(myds, "score")
        DataGridView1.DataSource = myds.Tables("score")
        DataGridView1.GridColor = Color.Green
        DataGridView1.ScrollBars = ScrollBars.Both
        DataGridView1.AllowUserToAddRows = False
        DataGridView1.Columns(0).ReadOnly = True
        DataGridView1.Columns(1).ReadOnly = True
        DataGridView1.Columns(0).DefaultCellStyle.BackColor = Color.LightGray
        DataGridView1.Columns(1).DefaultCellStyle.BackColor = Color.LightGray
        DataGridView1.Columns(2).DefaultCellStyle.BackColor = Color.LightYellow

        mytable = Exesql("select distinct 课程号 from allocate")
        ComboBox1.DataSource = mytable
        ComboBox1.DisplayMember = "课程号"
        ComboBox1.SelectedIndex = -1
        Label1.Text = "满足条件的成绩记录个数：" + myds.Tables("score").Rows.Count.ToString()
        SpcButton.Enabled = False
        ClearScoreButton.Enabled = False
        SaveButton.Enabled = False
    End Sub

    Private Sub SpcButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SpcButton.Click
        mysql = "insert into score(学号,课程号) select student.学号,allocate.课程号 from student,allocate where ltrim(student.班号)=ltrim(allocate.班号) And allocate.课程号 ='" + ComboBox1.Text.Trim + "'"
        Exesql(mysql)
        myconn.Open()
        mysql = "select * from score order by 课程号,学号"
        myda = New OracleDataAdapter(mysql, myconn)
        myds.Clear()
        myda.Fill(myds, "score")
        DataGridView1.DataSource = myds.Tables("score")
        myconn.Close()
        SpcButton.Enabled = False
        ClearScoreButton.Enabled = True
        Label1.Text = "满足条件的成绩记录个数：" + mytable.Rows.Count.ToString
        myconn.Close()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        condstr = "课程号 like '" & ComboBox1.Text.Trim & "%'"
        'myconn.ConnectionString = mystr
        ' myconn.Open()
        mysql = "select * from score where " + condstr
        mytable = Exesql(mysql)
        myconn.Close()

        If mytable.Rows.Count = 0 Then
            SpcButton.Enabled = True
            ClearScoreButton.Enabled = False
        Else
            SpcButton.Enabled = False
            ClearScoreButton.Enabled = True
        End If
    End Sub

    Private Sub ClearScoreButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearScoreButton.Click
        If MsgBox("真的要删除课程号为" & ComboBox1.Text.Trim & "的成绩记录吗？", MsgBoxStyle.YesNo, "删除确认") = MsgBoxResult.Yes Then
            mysql = "delete score where 课程号='" & ComboBox1.Text.Trim & "'"
            Exesql(mysql)
            mytable = Exesql("select * from score order by 课程号,学号")
            DataGridView1.DataSource = mytable
            Label1.Text = "满足条件的成绩记录个数：" + mytable.Rows.Count.ToString
            SpcButton.Enabled = True
            ClearScoreButton.Enabled = False

        End If
    End Sub

    Private Sub SaveButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveButton.Click
        Dim mycmdbuilder = New OracleCommandBuilder(myda)
        myda.Update(myds, "score")
        MsgBox("保存成功。", MsgBoxStyle.OkOnly, "提示")
        SaveButton.Enabled = False
    End Sub

    Private Sub ReturnButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReturnButton.Click
        Me.Close()
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub DataGridView1_CellValueChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellValueChanged
        SaveButton.Enabled = True
    End Sub
End Class