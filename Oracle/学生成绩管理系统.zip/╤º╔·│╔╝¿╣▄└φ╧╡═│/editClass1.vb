﻿Public Class editClass1

    Private Sub OkButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OkButton.Click
        If TextBox1.Text.Trim = "" Then
            MsgBox("必须输入班号", MsgBoxStyle.OkOnly, "信息提示")
            Exit Sub
        End If
        If TextBox2.Text.Trim = "" Then
            MsgBox("必须输入班级名", MsgBoxStyle.OkOnly, "信息提示")
            Exit Sub
        End If
        If flag = 1 Then
            mytable = Exesql("select * from class where 班号='" & TextBox1.Text.Trim & "'")
            If mytable.Rows.Count = 1 Then
                MsgBox("输入的班号重复，不能新增班级", MsgBoxStyle.OkOnly, "信息提示")
                TextBox1.Focus()
                Exit Sub
            Else
                mysql = "INSERT into class values('" & TextBox1.Text.Trim & "','" & TextBox2.Text.Trim & "')"
                Exesql(mysql)
                Me.Close()
            End If
        Else
            mysql = "UPDATE class set 班级名='" & TextBox2.Text & "' Where  班号='" & TextBox1.Text & "'"
            Exesql(mysql)
            Me.Close()
        End If
    End Sub

    Private Sub editClass1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If flag = 1 Then
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox1.Enabled = True
            TextBox1.Focus()
        Else
            mytable = Exesql("Select * from class where 班号='" & no & "'")
            TextBox1.Text = mytable.Rows(0)("班号").ToString.Trim
            TextBox2.Text = mytable.Rows(0)("班级名").ToString.Trim
            TextBox1.Enabled = False
            TextBox2.Focus()
        End If
    End Sub

    Private Sub CancelButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelButton.Click
        Me.Close()
    End Sub
End Class