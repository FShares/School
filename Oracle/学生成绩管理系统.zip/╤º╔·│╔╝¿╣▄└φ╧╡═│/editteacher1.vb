﻿Public Class editteacher1

    Private Sub editteacher1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        mytable = Exesql("SELECT distinct 职称 FROM teacher where 职称 is not null")
        ComboBox1.DataSource = mytable
        ComboBox1.DisplayMember = "职称"
        ComboBox1.SelectedIndex = -1
        mytable = Exesql("SELECT distinct 单位 FROM teacher where 单位 is not null")
        ComboBox2.DataSource = mytable
        ComboBox2.DisplayMember = "单位"
        ComboBox2.SelectedIndex = -1
        If flag = 1 Then
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
            ComboBox1.SelectedIndex = -1
            ComboBox2.SelectedIndex = -1
            Radiosex1.Checked = False
            Radiosex2.Checked = False
            TextBox1.Enabled = True
            TextBox1.Focus()
        Else
            mytable = Exesql("SELECT * FROM teacher WHERE 编号 ='" & no & "'")
            TextBox1.Text = mytable.Rows(0)("编号").ToString.Trim()
            TextBox2.Text = mytable.Rows(0)("姓名").ToString.Trim()
            TextBox3.Text = mytable.Rows(0)("出生日期").ToString.Trim() 'add
            Radiosex1.Checked = False
            Radiosex2.Checked = False
            If mytable.Rows(0)("性别").ToString.Trim = "男" Then
                Radiosex1.Checked = True
            End If
            If mytable.Rows(0)("性别").ToString.Trim = "女" Then
                Radiosex2.Checked = True
            End If

            If mytable.Rows(0)("性别").ToString.Trim = "男" Then
                Radiosex1.Checked = True
            End If
            ComboBox1.Text = mytable.Rows(0)("职称").ToString.Trim
            ComboBox2.Text = mytable.Rows(0)("单位").ToString.Trim
            TextBox1.Enabled = False
            TextBox2.Focus()
        End If

    End Sub

    Private Sub OkButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OkButton.Click
        If TextBox1.Text.Trim = "" Then
            MsgBox("必须输入编号", MsgBoxStyle.OkOnly, "信息提示")
            Exit Sub
        End If
        If TextBox2.Text.Trim = "" Then
            MsgBox("必须输入姓名", MsgBoxStyle.OkOnly, "信息提示")
            Exit Sub
        End If
        If TextBox3.Text.Trim <> "" And Not IsDate(TextBox3.Text.Trim) Then
            MsgBox("出生日期错误", MsgBoxStyle.OkOnly, "信息提示")
            Exit Sub
        End If
        Dim xb As String
        If Radiosex1.Checked Then
            xb = "男"
        ElseIf Radiosex2.Checked Then
            xb = "女"
        Else
            xb = ""
        End If
        If flag = 1 Then
            mytable = Exesql("SELECT * FROM teacher WHERE 编号 ='" & TextBox1.Text.Trim & "'")
            If mytable.Rows.Count = 1 Then
                MsgBox("输入的编号重复，不能新增", MsgBoxStyle.OkOnly, "信息提示")
                TextBox1.Focus()
                Exit Sub
            Else
                'mysql = "INSERT INTO teacher VALUES('" & TextBox1.Text.Trim & "','" & TextBox2.Text.Trim & ComboBox1.Text.Trim & "','" & ComboBox2.Text.Trim & "')" 
                mysql = "insert into teacher values('" & TextBox1.Text.Trim & "','" & TextBox2.Text.Trim & "','" & xb & "',to_date('" & TextBox3.Text.Trim & "','yyyy/mm/dd') ,'" & ComboBox1.Text.Trim & "','" & ComboBox2.Text.Trim & "')"

                Exesql(mysql)
                Me.Close()
            End If
        Else
            mysql = "update teacher set 姓名='" & TextBox2.Text.Trim & "',性别='" & xb & "',出生日期=to_date('" & TextBox3.Text.Trim & "','yyyy/mm/dd'),职称='" & ComboBox1.Text.Trim & "',单位='" & ComboBox2.Text.Trim & "' where 编号='" & TextBox1.Text.Trim & "'"
            Exesql(mysql)
            Me.Close()
        End If
    End Sub

    Private Sub CancelButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelButton.Click
        Me.Close()

    End Sub
End Class