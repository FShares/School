﻿Public Class allocateCourse

    Private Sub allocateCourse_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        mytable = exesql("select * from allocate")
        DataGridView1.AllowUserToAddRows = False
        DataGridView1.ReadOnly = True
        DataGridView1.DataSource = mytable
        DataGridView1.GridColor = Color.Green
        DataGridView1.ScrollBars = ScrollBars.Both
        Call enbutton()
    End Sub

    Private Sub AddButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddButton.Click
        flag = 1
        allocateCourse1.ShowDialog()
        mytable = exesql("select * from allocate")
        DataGridView1.DataSource = mytable
        Call enbutton()
    End Sub

    Private Sub UpdateButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UpdateButton.Click
        flag = 2
        If no <> "" And cno <> "" Then
            allocateCourse1.ShowDialog()
            mytable = exesql("select * from allocate")
            DataGridView1.DataSource = mytable
            Call enbutton()
        Else
            MsgBox("先选择要修改的课程安排记录", MsgBoxStyle.OkOnly, "信息提示")
        End If
    End Sub

    Private Sub DeleteButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteButton.Click
        If no <> "" And cno <> "" Then
            If MsgBox("真的要删除班号" + no.Trim + "的" + cno.Trim + "课程安排吗?", MsgBoxStyle.YesNo, "删除确认") = MsgBoxResult.Yes Then
                mysql = "Delete allocate where 班号 = '" + no.Trim + "'and 课程号 = '" + cno.Trim + "'"
                exesql(mysql)
                mytable = exesql("select * from allocate")
                DataGridView1.DataSource = mytable
                Call enbutton()
            End If
        Else
            MsgBox("先选择要删除的课程安排记录", MsgBoxStyle.OkOnly, "信息提示")
        End If
    End Sub

    Private Sub DataGridView1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        If e.RowIndex >= 0 And e.RowIndex < DataGridView1.RowCount Then
            no = DataGridView1.Rows(e.RowIndex).Cells(0).Value.ToString.Trim
            cno = DataGridView1.Rows(e.RowIndex).Cells(1).Value.ToString.Trim
        Else
            no = ""
            cno = ""
        End If
    End Sub

    Private Sub ReturnButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReturnButton.Click
        Me.Close()
    End Sub

    Private Sub enbutton()
        Label1.Text = "满足条件的安排任课教师记录人数:" + mytable.Rows.Count.ToString()
        If mytable.Rows.Count = 0 Then
            UpdateButton.Enabled = False
            DeleteButton.Enabled = False
            no = ""
            cno = ""
        Else
            UpdateButton.Enabled = True
            DeleteButton.Enabled = True
            no = mytable.Rows.Item(0)("班号").ToString.Trim
            cno = mytable.Rows.Item(0)("课程号").ToString.Trim
        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class