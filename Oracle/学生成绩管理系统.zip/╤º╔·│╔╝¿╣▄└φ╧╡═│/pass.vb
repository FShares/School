﻿Public Class pass
    Dim n As Integer = 0
    Private Sub pass_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox1.Text = "admin"
        TextBox2.Text = "123456"
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        mysql = "select * from users where 用户名='" & TextBox1.Text.Trim + "' AND 密码='" & TextBox2.Text.Trim & "'"
        mytable = Exesql(mysql)
        If mytable.Rows.Count = 0 Then
            n += 1
            If n < 3 Then
                MsgBox("不存在该用户，继续登录", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "信息提示")
                TextBox1.Text = ""
                TextBox2.Text = ""
                TextBox1.Focus()
            Else
                MsgBox("已登录失败次，退出系统", MsgBoxStyle.OkOnly + MsgBoxStyle.Exclamation, "信息提示")
                Me.Close()
            End If
        Else
            userlevel = mytable.Rows(0)("级别").ToString.Trim
            no = TextBox1.Text.Trim
            logontime = Now
            main.ShowDialog()
            Me.Close()
            Me.Hide()
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class