﻿Imports System.Data.OracleClient
Module CommModule
    Public userlevel As String
    Public flag As Integer
    Public no As String
    Public cno As String
    Public mytable As DataTable
    Public mysql As String
    Public condstr As String = ""
    Public mydv As New DataView()
    Public logontime As Date
    Public Function Exesql(ByVal mysql As String) As DataTable
        Dim myconn As New OracleConnection
        Dim mycmd As New OracleCommand
        Dim mystr As String
        mystr = "data source=orcl;user id=scott;password=tiger"
        myconn.ConnectionString = mystr
        myconn.Open()
        If Strings.InStr("INSERT,DELETE,UPDATE", Split(mysql, " ")(0).ToUpper) Then
            mycmd.Connection = myconn
            mycmd.CommandText = mysql
            mycmd.CommandType = CommandType.Text
            mycmd.ExecuteOracleNonQuery(mysql)
            myconn.Close()
            Return Nothing
        Else
            Dim myda As New OracleDataAdapter(mysql, myconn)
            Dim myds As New DataSet
            myda.Fill(myds)
            myconn.Close()
            Return myds.Tables(0)
        End If
    End Function
End Module
