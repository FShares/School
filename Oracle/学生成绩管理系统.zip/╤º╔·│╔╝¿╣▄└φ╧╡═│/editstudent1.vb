﻿Public Class editstudent1
    Private Sub editstudent1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If flag = 1 Then
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
            TextBox4.Text = ""
            Radiosex1.Checked = False
            Radiosex2.Checked = False
            TextBox1.Enabled = True
            TextBox1.Focus()
        Else
            mytable = Exesql("select * from student where 学号='" & no & "'")
            TextBox1.Text = mytable.Rows(0)("学号").ToString()
            TextBox2.Text = mytable.Rows(0)("姓名").ToString()
            TextBox3.Text = mytable.Rows(0)("出生日期").ToString()
            If mytable.Rows(0)("出生日期") Is DBNull.Value Then
                TextBox3.Text = ""
            Else
                TextBox3.Text = mytable.Rows(0)("出生日期")
            End If
            TextBox4.Text = mytable.Rows(0)("班号").ToString()
            Radiosex1.Checked = False
            Radiosex2.Checked = False
            If mytable.Rows(0)("性别").ToString = "男" Then
                Radiosex1.Checked = True
            Else
                Radiosex2.Checked = True
            End If
        End If

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub OkButton_Click(sender As Object, e As EventArgs) Handles OkButton.Click
        If Trim(TextBox1.Text) = "" Then
            MsgBox("必须输入学号", MsgBoxStyle.OkOnly, "信息提示")
            Exit Sub
        End If
        If Trim(TextBox2.Text) = "" Then
            MsgBox("必须输入姓名", MsgBoxStyle.OkOnly, "信息提示")
            Exit Sub
        End If
        If Trim(TextBox3.Text) <> "" And Not IsDate(TextBox3.Text) Then
            MsgBox("出生日期输入错误", MsgBoxStyle.OkOnly, "信息提示")
            Exit Sub
        End If
        Dim xb As String
        If Radiosex1.Checked Then
            xb = "男"
        ElseIf Radiosex2.Checked Then
            xb = "女"
        Else
            xb = ""
        End If

        If flag = 1 Then
            mytable = Exesql("select * from student where 学号='" & TextBox1.Text & "'")
            If mytable.Rows.Count = 1 Then
                MsgBox("输入的学号重复，不能新增学生记录", MsgBoxStyle.OkOnly, "信息提示")
                TextBox1.Focus()
                Exit Sub
            Else
                mysql = "insert into student values('" & TextBox1.Text.Trim & "','" & TextBox2.Text.Trim & "','" & xb & "',to_date('" & TextBox3.Text.Trim & "','yyyy/mm/dd'),'" & TextBox4.Text.Trim & "')"
                mytable = Exesql(mysql)
                Me.Close()
            End If
        Else
            mysql = "update student set 姓名='" & TextBox2.Text.Trim & "',性别='" & xb &"',出生日期=to_date('" & TextBox3.Text.Trim & "','yyyy/mm/dd'),班号='" & TextBox4.Text.Trim &"' where 学号='" & TextBox1.Text.Trim & "'"
            mytable = Exesql(mysql)
            Me.Close()
        End If
    End Sub
End Class