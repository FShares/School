﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class main
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.班级数据管理ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.班级数据编辑ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.班级数据查询ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.学生数据管理ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.学生数据编辑ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.学生数据查询ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.退出CtrlXToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.教师数据管理ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.教师数据编辑ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.教师数据查询ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.课程数据管理ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.课程数据编辑ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.课程数据查询ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.课程安排管理ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.安排任课教师ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.查询任课教师ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.成绩数据管理ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.成绩数据编辑ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.成绩数据查询ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.系统维护ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.设置系统用户ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.系统初始化ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.MenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.班级数据管理ToolStripMenuItem, Me.学生数据管理ToolStripMenuItem, Me.教师数据管理ToolStripMenuItem, Me.课程数据管理ToolStripMenuItem, Me.课程安排管理ToolStripMenuItem, Me.成绩数据管理ToolStripMenuItem, Me.系统维护ToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(630, 25)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        '班级数据管理ToolStripMenuItem
        '
        Me.班级数据管理ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.班级数据编辑ToolStripMenuItem, Me.班级数据查询ToolStripMenuItem})
        Me.班级数据管理ToolStripMenuItem.Name = "班级数据管理ToolStripMenuItem"
        Me.班级数据管理ToolStripMenuItem.Size = New System.Drawing.Size(92, 21)
        Me.班级数据管理ToolStripMenuItem.Text = "班级数据管理"
        '
        '班级数据编辑ToolStripMenuItem
        '
        Me.班级数据编辑ToolStripMenuItem.Name = "班级数据编辑ToolStripMenuItem"
        Me.班级数据编辑ToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.班级数据编辑ToolStripMenuItem.Text = "班级数据编辑"
        '
        '班级数据查询ToolStripMenuItem
        '
        Me.班级数据查询ToolStripMenuItem.Name = "班级数据查询ToolStripMenuItem"
        Me.班级数据查询ToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.班级数据查询ToolStripMenuItem.Text = "班级数据查询"
        '
        '学生数据管理ToolStripMenuItem
        '
        Me.学生数据管理ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.学生数据编辑ToolStripMenuItem, Me.学生数据查询ToolStripMenuItem, Me.退出CtrlXToolStripMenuItem})
        Me.学生数据管理ToolStripMenuItem.Name = "学生数据管理ToolStripMenuItem"
        Me.学生数据管理ToolStripMenuItem.Size = New System.Drawing.Size(92, 21)
        Me.学生数据管理ToolStripMenuItem.Text = "学生数据管理"
        '
        '学生数据编辑ToolStripMenuItem
        '
        Me.学生数据编辑ToolStripMenuItem.Name = "学生数据编辑ToolStripMenuItem"
        Me.学生数据编辑ToolStripMenuItem.Size = New System.Drawing.Size(153, 22)
        Me.学生数据编辑ToolStripMenuItem.Text = "学生数据编辑"
        '
        '学生数据查询ToolStripMenuItem
        '
        Me.学生数据查询ToolStripMenuItem.Name = "学生数据查询ToolStripMenuItem"
        Me.学生数据查询ToolStripMenuItem.Size = New System.Drawing.Size(153, 22)
        Me.学生数据查询ToolStripMenuItem.Text = "学生数据查询"
        '
        '退出CtrlXToolStripMenuItem
        '
        Me.退出CtrlXToolStripMenuItem.Name = "退出CtrlXToolStripMenuItem"
        Me.退出CtrlXToolStripMenuItem.Size = New System.Drawing.Size(153, 22)
        Me.退出CtrlXToolStripMenuItem.Text = "退出    Ctrl+X"
        '
        '教师数据管理ToolStripMenuItem
        '
        Me.教师数据管理ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.教师数据编辑ToolStripMenuItem, Me.教师数据查询ToolStripMenuItem})
        Me.教师数据管理ToolStripMenuItem.Name = "教师数据管理ToolStripMenuItem"
        Me.教师数据管理ToolStripMenuItem.Size = New System.Drawing.Size(92, 21)
        Me.教师数据管理ToolStripMenuItem.Text = "教师数据管理"
        '
        '教师数据编辑ToolStripMenuItem
        '
        Me.教师数据编辑ToolStripMenuItem.Name = "教师数据编辑ToolStripMenuItem"
        Me.教师数据编辑ToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.教师数据编辑ToolStripMenuItem.Text = "教师数据编辑"
        '
        '教师数据查询ToolStripMenuItem
        '
        Me.教师数据查询ToolStripMenuItem.Name = "教师数据查询ToolStripMenuItem"
        Me.教师数据查询ToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.教师数据查询ToolStripMenuItem.Text = "教师数据查询"
        '
        '课程数据管理ToolStripMenuItem
        '
        Me.课程数据管理ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.课程数据编辑ToolStripMenuItem, Me.课程数据查询ToolStripMenuItem})
        Me.课程数据管理ToolStripMenuItem.Name = "课程数据管理ToolStripMenuItem"
        Me.课程数据管理ToolStripMenuItem.Size = New System.Drawing.Size(92, 21)
        Me.课程数据管理ToolStripMenuItem.Text = "课程数据管理"
        '
        '课程数据编辑ToolStripMenuItem
        '
        Me.课程数据编辑ToolStripMenuItem.Name = "课程数据编辑ToolStripMenuItem"
        Me.课程数据编辑ToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.课程数据编辑ToolStripMenuItem.Text = "课程数据编辑"
        '
        '课程数据查询ToolStripMenuItem
        '
        Me.课程数据查询ToolStripMenuItem.Name = "课程数据查询ToolStripMenuItem"
        Me.课程数据查询ToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.课程数据查询ToolStripMenuItem.Text = "课程数据查询"
        '
        '课程安排管理ToolStripMenuItem
        '
        Me.课程安排管理ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.安排任课教师ToolStripMenuItem, Me.查询任课教师ToolStripMenuItem})
        Me.课程安排管理ToolStripMenuItem.Name = "课程安排管理ToolStripMenuItem"
        Me.课程安排管理ToolStripMenuItem.Size = New System.Drawing.Size(92, 21)
        Me.课程安排管理ToolStripMenuItem.Text = "课程安排管理"
        '
        '安排任课教师ToolStripMenuItem
        '
        Me.安排任课教师ToolStripMenuItem.Name = "安排任课教师ToolStripMenuItem"
        Me.安排任课教师ToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.安排任课教师ToolStripMenuItem.Text = "安排任课教师"
        '
        '查询任课教师ToolStripMenuItem
        '
        Me.查询任课教师ToolStripMenuItem.Name = "查询任课教师ToolStripMenuItem"
        Me.查询任课教师ToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.查询任课教师ToolStripMenuItem.Text = "查询任课教师"
        '
        '成绩数据管理ToolStripMenuItem
        '
        Me.成绩数据管理ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.成绩数据编辑ToolStripMenuItem, Me.成绩数据查询ToolStripMenuItem})
        Me.成绩数据管理ToolStripMenuItem.Name = "成绩数据管理ToolStripMenuItem"
        Me.成绩数据管理ToolStripMenuItem.Size = New System.Drawing.Size(92, 21)
        Me.成绩数据管理ToolStripMenuItem.Text = "成绩数据管理"
        '
        '成绩数据编辑ToolStripMenuItem
        '
        Me.成绩数据编辑ToolStripMenuItem.Name = "成绩数据编辑ToolStripMenuItem"
        Me.成绩数据编辑ToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.成绩数据编辑ToolStripMenuItem.Text = "成绩数据编辑"
        '
        '成绩数据查询ToolStripMenuItem
        '
        Me.成绩数据查询ToolStripMenuItem.Name = "成绩数据查询ToolStripMenuItem"
        Me.成绩数据查询ToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.成绩数据查询ToolStripMenuItem.Text = "成绩数据查询"
        '
        '系统维护ToolStripMenuItem
        '
        Me.系统维护ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.设置系统用户ToolStripMenuItem, Me.系统初始化ToolStripMenuItem})
        Me.系统维护ToolStripMenuItem.Name = "系统维护ToolStripMenuItem"
        Me.系统维护ToolStripMenuItem.Size = New System.Drawing.Size(68, 21)
        Me.系统维护ToolStripMenuItem.Text = "系统维护"
        '
        '设置系统用户ToolStripMenuItem
        '
        Me.设置系统用户ToolStripMenuItem.Name = "设置系统用户ToolStripMenuItem"
        Me.设置系统用户ToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.设置系统用户ToolStripMenuItem.Text = "设置系统用户"
        '
        '系统初始化ToolStripMenuItem
        '
        Me.系统初始化ToolStripMenuItem.Name = "系统初始化ToolStripMenuItem"
        Me.系统初始化ToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.系统初始化ToolStripMenuItem.Text = "系统初始化"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 280)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(630, 22)
        Me.StatusStrip1.TabIndex = 2
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(134, 17)
        Me.ToolStripStatusLabel1.Text = "ToolStripStatusLabel1"
        '
        'main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(630, 302)
        Me.ControlBox = False
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "学生成绩管理系统"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents 学生数据管理ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 教师数据管理ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 课程数据管理ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 课程安排管理ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 学生数据编辑ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 成绩数据管理ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 系统维护ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 学生数据查询ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 退出CtrlXToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 教师数据编辑ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 教师数据查询ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 课程数据编辑ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 课程数据查询ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 安排任课教师ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 查询任课教师ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 成绩数据编辑ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 成绩数据查询ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 设置系统用户ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 系统初始化ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 班级数据管理ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 班级数据编辑ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 班级数据查询ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
End Class
