#include "ch11.h"
#define FIFO_FILE "myfifo"
#define TEN_MEG          1024*1024*10
